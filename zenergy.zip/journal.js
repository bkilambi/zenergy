var cardContainer = $('.card-container');
var submit = $('.submit-btn');
console.log("in file");
submit.on("click", display);

function display(event) {
  console.log("clicked");
  event.preventDefault();
  var inp=$(`card-container`)
  var name = $('.name').val();

  inp.append(`
    <p class="name-card">${name} </p>
  `); 
}

